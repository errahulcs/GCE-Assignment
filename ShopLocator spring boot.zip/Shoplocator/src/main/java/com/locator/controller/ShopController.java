package com.locator.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.locator.DTO.ResponseDTO;
import com.locator.DTO.ShopsDataDTO;
import com.locator.domain.Shop;
import com.locator.service.ShopService;

@Controller
public class ShopController {

	@Autowired
	private ShopService shopService;

	// This API is responsible for saving the shop imformation into the database

	@RequestMapping(value = "/saveShop", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public @ResponseBody ResponseDTO saveShop(@RequestBody Shop shop) {
		return shopService.saveShop(shop);
	}

	// This API is responsible for getting all shops based on current lat , lng and radius value.

	@RequestMapping(value = "/getShops", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<ShopsDataDTO> getShop(@RequestParam float lat, @RequestParam float lng,
			@RequestParam float dist) {

		return shopService.getDataByLatLng(lat, lng, dist);
	}

}
