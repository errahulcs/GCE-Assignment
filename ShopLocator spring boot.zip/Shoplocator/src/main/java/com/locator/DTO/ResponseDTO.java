package com.locator.DTO;

public class ResponseDTO {

	public String message;
	public String status;
}
