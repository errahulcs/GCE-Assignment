package com.locator.DTO;

import java.text.DecimalFormat;

public class ShopsDataDTO {

	public Integer shopId;
	public String shopName;
	public String category;
	public String ownerName;
	private double distance;

	public double getDistance() {
		DecimalFormat format = new DecimalFormat("##.00");
		return Double.parseDouble(format.format((distance * 1.60934)));
	}

	public void setDistance(double distance) {

		this.distance = distance;
	}

}
