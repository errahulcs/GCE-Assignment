package com.locator.repository;

import org.springframework.data.repository.CrudRepository;

import com.locator.domain.Shop;

public interface ShopRepository extends CrudRepository<Shop, Long>{

 
}
