package com.locator.service.Impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.locator.DTO.ResponseDTO;
import com.locator.DTO.ShopsDataDTO;
import com.locator.domain.Shop;
import com.locator.repository.ShopRepository;
import com.locator.service.ShopService;

@Service
public class ShopServiceImpl implements ShopService {

	@Autowired
	private ShopRepository shopRepo;

	@PersistenceContext
	private EntityManager entityManager;

	public List<ShopsDataDTO> getDataByLatLng(double lat, double lng, float dist) {
		String queryStr = "SELECT * FROM (SELECT shop_id,category,owner_name,shop_name,  3956 * 2 * ASIN(SQRT(POWER(SIN((? - abs(lat)) * pi()/180 / 2), 2) + COS(? * pi()/180 ) * COS(abs(lat) * pi()/180)  * POWER(SIN((? -lng) * pi()/180 / 2), 2) )) as  distance FROM shop) R WHERE R.distance <=?";
		List<ShopsDataDTO> shop = new ArrayList<>();
		try {
			Query query = entityManager.createNativeQuery(queryStr);
			query.setParameter(1, lat);
			query.setParameter(2, lat);
			query.setParameter(3, lng);
			query.setParameter(4, dist);
			List<Object[]> listData = query.getResultList();

			for (Object[] obj : listData) {
				ShopsDataDTO o = new ShopsDataDTO();
				o.shopId = (Integer) obj[0];
				o.category = (String) obj[1];
				o.ownerName = (String) obj[2];
				o.shopName = (String) obj[3];
				o.setDistance((double) obj[4]);
				shop.add(o);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return shop;
	}

	public ResponseDTO saveShop(Shop shop) {
		ResponseDTO respDTO = new ResponseDTO();
		try {
			shopRepo.save(shop);
			respDTO.message = "shop added";
			respDTO.status = "success";
		} catch (Exception e) {
			respDTO.message = e.getMessage();
			respDTO.status = "error";
		}
		return respDTO;
	}
}
