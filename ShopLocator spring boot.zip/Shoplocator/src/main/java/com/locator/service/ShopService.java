package com.locator.service;

import java.util.List;

import com.locator.DTO.ResponseDTO;
import com.locator.DTO.ShopsDataDTO;
import com.locator.domain.Shop;


public interface ShopService {

	public List<ShopsDataDTO> getDataByLatLng(double lat,double lng, float dist);
	
	public ResponseDTO saveShop(Shop shop);
}
