package com.locator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
//@EnableJpaRepositories("com.locator.service")
//@EntityScan("com.locator.domain") 
public class ShoplocatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoplocatorApplication.class, args);
	}

}
