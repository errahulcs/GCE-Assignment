import { Component, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { MainService } from '../shared/services/main.service';
import { AppComponent } from '../app.component'
@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})



export class LocationComponent {
  @ViewChild('changeLabDialog') public changeLabDialog;
  @ViewChild('onlyAttentionMsz') public onlyAttentionMsz;
  @ViewChild('onlySuccessMsz') public onlySuccessMsz;
  @ViewChild('onlyErrorMsz') public onlyErrorMsz; 
 
  defaultLoc = "location";

  constructor(public cd: ChangeDetectorRef,
    public appComponent: AppComponent,
    public service: MainService,
    private router: Router,

    private elementRef: ElementRef, private route: ActivatedRoute) {
    }

  ngAfterViewInit() {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAsc2nVgg2002WgRT-ycICu5TXYAjp7yrk&libraries=places&callback=initAutocomplete";
    this.elementRef.nativeElement.appendChild(s);
  }

  initAutocomplete(){
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAsc2nVgg2002WgRT-ycICu5TXYAjp7yrk&libraries=places&callback=initAutocomplete";
    this.elementRef.nativeElement.appendChild(s);
  }
  getShopByRadius(radius){
    this.service.radius=radius;
    if ( this.service.lat != undefined &&  this.service.lng != undefined) {
      this.getShopByLocation(this.service.lat,this.service.lng)
    }else{
      alert("please select location");
    }
  }
  getShopByLocation(lat,lng){
    if (lat != undefined && lng != undefined) {
      this.service.lat=lat;
      this.service.lng=lng;
     this.service.shopData =  this.service.getShopsInfo(lat,lng,this.service.radius);
     console.log(this.service.shopData);
  }
  }

  goToShopCreator(){
    this.router.navigate(['/addShop']); 
  }
}


