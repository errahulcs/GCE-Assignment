import { Component, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { MainService } from '../shared/services/main.service';
import { AppComponent } from '../app.component'
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {

  @ViewChild('changePlatter') public changePlatter;
  @ViewChild('onlyAttentionMsz') public onlyAttentionMsz;
  @ViewChild("custInfoPanel") custInfoPanel;
  @ViewChild('onlySuccessMsz') public onlySuccessMsz;
  @ViewChild('onlyErrorMsz') public onlyErrorMsz;

  constructor(
    public appComponent: AppComponent,
    public service: MainService,
    private router: Router,

    private elementRef: ElementRef, private route: ActivatedRoute){
  }

  ngAfterViewInit() {
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAsc2nVgg2002WgRT-ycICu5TXYAjp7yrk&libraries=places&callback=initAutocomplete";
    this.elementRef.nativeElement.appendChild(s);
  }


  initAutocomplete(){
    var s = document.createElement("script");
    s.type = "text/javascript";
    s.src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAsc2nVgg2002WgRT-ycICu5TXYAjp7yrk&libraries=places&callback=initAutocomplete";
    this.elementRef.nativeElement.appendChild(s);
  }

  getShopByLocation(lat,lng){
    if (lat != undefined && lng != undefined) {
      this.service.lat=lat;
      this.service.lng=lng;
  }
  }

  getValues(shopName, category,ownerName){

    if(shopName=="" || shopName==undefined){
      alert("Please enter shop name");
      return false;
    }
    if(category=="" || category==undefined){
      alert("Please enter category");
      return false;
    }
    if(ownerName=="" || ownerName==undefined){
      alert("Please enter owner name");
      return false;
    }
    if(this.service.lat=="" || this.service.lat==undefined || this.service.lng=="" || this.service.lng==undefined){
      alert("Please select address from loction field");
    }
    this.service.saveShopsByLocation(shopName,category,ownerName);
  }

  goToShopSearch(){
    this.router.navigate(['/location']);
  }
}



