import { CanActivate } from '@angular/router';
import {Injectable } from '@angular/core';


@Injectable()
export  class ActivateGuardService implements CanActivate {
  
  private can: boolean = false;

  canActivate() {
    return true;
  }

  setCanActivate(can) {
    this.can = can;
  }
}
