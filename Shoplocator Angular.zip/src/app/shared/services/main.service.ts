import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { IfStmt } from '@angular/compiler';
// import for order list from cart menu


@Injectable()
export class MainService {

  // Global varibles
   public lat:any;
   public lng:any;
   public radius:any=50;
   public  serverFixedURL:any;
   public baseUrl= '';
   public serverUrl= '';
   public shopData:any;

   constructor(private http: HttpClient,location:Location) {
     this.serverFixedURL = MainService.getAbsoluteDomainUrl();
     this.baseUrl= this.serverFixedURL+'/path/';
     this.serverUrl= this.serverFixedURL;

     if("http://localhost:4200"== this.serverFixedURL|| "http://localhost:4300"== this.serverFixedURL || this.serverFixedURL==undefined ){
      this.baseUrl='http://localhost:9090/';
    
     }else{
       this.baseUrl='http://localhost:9090/';
     }
    }

  saveShopsByLocation(shopName,category,ownerName) {
    var bodyString={};
    if(this.lat==0 ||  this.lng == 0 ){
      return false;
    }else{
      this.lat=this.lat;
      this.lng=this.lng;
      bodyString = {
        "lat": this.lat,
        "lng": this.lng,
        "ownerName":ownerName,
        "shopName":shopName,
        "category":category
      }
    }
    bodyString = JSON.stringify(bodyString);
    const header = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});
    const Url = this.baseUrl + 'saveShop';
    this.http.post(Url,bodyString,{headers:header}).subscribe((result) => {
      alert("Data saved");
    });
  }

  getShopsInfo(lat,lng,dist) {
     this.http.get(this.baseUrl + 'getShops?lat='+lat+'&lng='+lng+'&dist='+dist).subscribe((result) => {
      this.shopData =  result;
      });
   }



  public static getAbsoluteDomainUrl(): string {
      if (window
          && "location" in window
          && "protocol" in window.location
          && "host" in window.location) {
          return window.location.protocol + "//" + window.location.host;
      }
      return null;
  }

}
