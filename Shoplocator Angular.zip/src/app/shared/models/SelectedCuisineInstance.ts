export class SelectedCuisineInstance {

    constructor(public selectedCuisine: any) {

    }
}

