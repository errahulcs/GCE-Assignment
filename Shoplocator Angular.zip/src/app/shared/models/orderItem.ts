export class OrderItem {
    itemCount: number;
    constructor(
        public itemName: string,
        public itemPrice: number,
        public imageUrl: string,
        public menuId: number,
        public quantity:number,
        public section: any,
        public addOn: any,
        public instructions = "",
        public cuisineType = "Default"

    ) {
        this.itemCount = quantity;
    }



}

export class AddOn {
    constructor(
        public itemName: string,
        public itemPrice: number,
        public itemId: number,
        public quantity: Number
    ) {
    }
}

export class Section {
    constructor(
        public sectionId: number,
        public name: string,
        public shortName: string,
        public price: number,
        public platterSectionType: string,
        public items: Array<Items>,
    ) {

    }
}

export class Items {

    constructor(
        public itemId: number,
        public countryId: number,
        public vendorId: number,
        public name: string,
        public price: number,
        public quantityInG: number,
        public itemType: string,
        public isDishReplaceable: boolean
    ) {

    }
}
