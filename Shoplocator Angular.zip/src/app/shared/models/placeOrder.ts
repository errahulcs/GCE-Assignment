
export class PlaceOrder{

//  public item = {
//    menuId: Number,
//    instructions:String,
//    dishSizeId:Number, //optional in case you are adding Dish with different size, eg. small, large
//    quantity:Number,
//   }

// public addOns = {
//     id :Number,
//     quantity:Number,
//     dishSizeId:Number////optional in case you are adding addOn with different size, eg. small, large
// }

public discountList = {
    id:Number,
   name:String,
   category:String,
   type:String,
   value:Number
}

public customer={
   name:"",
   phone:"",
   email: "",
   address:"",
   deliveryArea:"",
   latitude:0.0,
   longitude:0.0,
   city:"",
   id: Number
}

 public  Order={
   instructions:"",
   paymentMethod:"",
   orderSource:"",
   deliveryCharges:Number,
   deliveryDateTime:"", // format MM-DD-YYYY HH:MM
   couponCode:[],
   items:[],
}
public countryId:number;

public placeOrder ={order:this.Order, customer:this.customer, countryId:this.countryId }

}
