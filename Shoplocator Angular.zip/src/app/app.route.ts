import { ModuleWithProviders} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivateGuardService } from './shared/services/activate-guard.service';

import { LocationComponent } from './location/location.component';
import { MenuComponent } from './menu/menu.component';
import { NotFoundComponent } from './not-found/not-found.component';

const MAINMENU_ROUTES: Routes = [
    {
         path: '',
         redirectTo: '/location',
         pathMatch: 'full'
    },
    {
         path: 'location',
         component: LocationComponent
     },
    {
        path: 'addShop',
        component: MenuComponent,
        canActivate: [ActivateGuardService]
     },
    {
        path: '**',
        component: NotFoundComponent
    }

];
export const CONST_ROUTING: ModuleWithProviders = RouterModule.forRoot(MAINMENU_ROUTES, { useHash: true , anchorScrolling: 'enabled', scrollPositionRestoration: 'enabled'});
