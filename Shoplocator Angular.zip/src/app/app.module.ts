import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ActivateGuardService } from './shared/services/activate-guard.service';
import { MainService } from './shared/services/main.service';
import { AppComponent } from './app.component';
import { LocationComponent } from './location/location.component';
import {MenuComponent} from './menu/menu.component'
import { CONST_ROUTING} from './app.route';
import { NotFoundComponent } from './not-found/not-found.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';


import {MatInputModule} from '@angular/material/input';

@NgModule({
  declarations: [
    AppComponent,
    LocationComponent,
    MenuComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CONST_ROUTING,
    MatInputModule,
    NgbModule,
    MDBBootstrapModule.forRoot()],
    providers: [ MainService , ActivateGuardService],
  bootstrap: [AppComponent],
  
})
export class AppModule {

}
